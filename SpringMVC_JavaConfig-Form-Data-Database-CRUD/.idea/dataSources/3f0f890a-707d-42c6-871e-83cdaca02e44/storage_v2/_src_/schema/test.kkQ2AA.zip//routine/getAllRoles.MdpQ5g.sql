CREATE PROCEDURE getAllRoles()
  SELECT * FROM roles;

