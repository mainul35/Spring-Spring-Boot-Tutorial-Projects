CREATE PROCEDURE getAllUsers()
  BEGIN
	#Routine body goes here...
	SELECT * FROM userdetails;
END;

