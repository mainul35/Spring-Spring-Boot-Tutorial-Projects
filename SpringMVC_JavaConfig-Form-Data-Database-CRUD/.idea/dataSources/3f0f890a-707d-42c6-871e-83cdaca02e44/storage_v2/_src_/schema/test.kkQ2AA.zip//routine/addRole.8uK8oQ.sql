CREATE PROCEDURE addRole(IN r_id VARCHAR(255), IN r_name VARCHAR(255))
  BEGIN
	#Routine body goes here...
	INSERT INTO roles(roles.role_id, roles.role_name)VALUES(r_id,r_name);
END;

